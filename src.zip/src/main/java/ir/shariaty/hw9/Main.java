package ir.shariaty.hw9;

import static android.content.Context.CLIPBOARD_SERVICE;

import static com.google.android.material.internal.ContextUtils.getActivity;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

public class Main extends RecyclerView.Adapter<Main.MyViewHolder> {

    String e[],f[],g[];
    Context context;

    public Main(Context ct, String a[], String b[], String c[]) {
        context= ct;
        e = a;
        f=b;
        g=c;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View view =inflater.inflate(R.layout.activity_main2,parent,false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.text1.setText(e[position]);
        holder.text2.setText(f[position]);
        holder.text3.setText(g[position]);

        holder.like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "added to Fav library",
                        Toast.LENGTH_LONG).show();

            }
        });

        holder.save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "added to Bookmark library",
                        Toast.LENGTH_LONG).show();

            }
        });
        holder.copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("label", f[position]);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(context, "copy in clipboard",
                        Toast.LENGTH_LONG).show();
            }
        });


        holder.share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, f[position]);
                context.startActivity(Intent.createChooser(shareIntent,"please choose :"));


            }
        });
        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "edit is unavailable",
                        Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return e.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView text1,text2,text3;

        ImageButton like,save,copy,share,edit;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            text1=itemView.findViewById(R.id.text2);
            text2=itemView.findViewById(R.id.text3);
            text3=itemView.findViewById(R.id.text2);
            like=itemView.findViewById(R.id.like);
            save=itemView.findViewById(R.id.save);
            copy=itemView.findViewById(R.id.copy);
            share=itemView.findViewById(R.id.share);
            edit=itemView.findViewById(R.id.edit);


        }
    }


}
