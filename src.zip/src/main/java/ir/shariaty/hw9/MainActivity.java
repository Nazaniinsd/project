package ir.shariaty.hw9;



import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    String a[],b[],c[];
    RecyclerView recycleview;
    ImageButton info;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.btn1);
        navigation.setBackground(null);

        recycleview=findViewById(R.id.recy);
        a=getResources().getStringArray(R.array.p_name);
        b=getResources().getStringArray(R.array.p_dec);
        c=getResources().getStringArray(R.array.p_name2);
        info=findViewById(R.id.info);

        Main MyAdaptor= new Main(this,a,b,c);
        recycleview.setAdapter(MyAdaptor);
        recycleview.setLayoutManager(new LinearLayoutManager(this));

        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "nazanin sadeghi",
                        Toast.LENGTH_LONG).show();
            }
        });
    }


}
